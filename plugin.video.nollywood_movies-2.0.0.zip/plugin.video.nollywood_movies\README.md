﻿# Nollywood Movies  Kodi Add-on

**Stream Nollywood movies in Kodi!**  
10+ channels, Auto HD, no login.

---

## Install from ZIP

[Download v2.0.0](plugin.video.nollywood_movies-2.0.0.zip)

1. Kodi  Add-ons  **Install from ZIP file**  
2. Select ZIP  Done!

---

## Legal

Bundles **yt-dlp** under [Unlicense](resources/lib/third_party/yt_dlp/LICENSE).  
See: [Third-Party](resources/lib/third_party/yt_dlp/README_THIRD_PARTY.md)

---

**Made with love for African cinema**
