﻿# Nollywood Movies  Kodi Video Add-on

**Stream Nollywood classics & new releases in Kodi!**  
Powered by **yt-dlp** (clean, legal, bundled).

---

## Install from ZIP

[Download v2.0.0](plugin.video.nollywood_movies-2.0.0.zip)

1. Kodi  Add-ons  Box icon  **Install from ZIP file**  
2. Select the ZIP  Done!

---

## Features

- 10+ Nollywood YouTube channels  
- Auto HD, search, no login  
- GitHub-safe, no secrets

---

## Legal

Bundles **yt-dlp** under [Unlicense](resources/lib/third_party/yt_dlp/LICENSE).  
See: [Third-Party](resources/lib/third_party/yt_dlp/README_THIRD_PARTY.md)

---

**Made with love for African cinema**
