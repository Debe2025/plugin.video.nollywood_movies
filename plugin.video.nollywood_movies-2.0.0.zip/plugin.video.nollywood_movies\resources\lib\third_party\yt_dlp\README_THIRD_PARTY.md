﻿THIRD-PARTY NOTICE: yt-dlp Bundle

This folder contains a bundled copy of yt-dlp (extractors & core only).
Original source: https://github.com/yt-dlp/yt-dlp
Version: Latest master (as of 2025-11-14)
Copyright (c) 20202025 yt-dlp contributors
Licensed under the Unlicense (public domain).

Modifications:
- Excluded shahid.py extractor (contains test AWS keys  security concern).
- Bundled for Kodi add-on: plugin.video.nollywood_movies by coolitis.

Full yt-dlp repo: https://github.com/yt-dlp/yt-dlp
For updates, re-run the bundle script.
